CREATE RULE geometry_columns_delete AS
    ON DELETE TO public.geometry_columns DO INSTEAD NOTHING;

