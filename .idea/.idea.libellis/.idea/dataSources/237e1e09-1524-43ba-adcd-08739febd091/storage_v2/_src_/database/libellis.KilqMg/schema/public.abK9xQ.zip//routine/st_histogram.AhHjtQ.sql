create function st_histogram(rast raster, nband integer, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, TRUE, 1, $3, NULL, $4)
$$;

comment on function st_histogram(raster, integer, integer, boolean, out double precision, out double precision, out bigint, out double precision) is 'args: rast, nband, bins, right - Returns a set of record summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(raster, integer, integer, boolean, out double precision, out double precision, out bigint, out double precision) owner to pmfarr;

