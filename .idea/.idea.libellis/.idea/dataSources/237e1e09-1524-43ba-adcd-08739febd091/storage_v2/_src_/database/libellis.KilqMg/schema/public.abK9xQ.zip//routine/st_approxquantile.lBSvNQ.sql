create function st_approxquantile(rastertable text, rastercolumn text, sample_percent double precision, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
  stable
  language sql
as
$$
SELECT public._ST_quantile($1, $2, 1, TRUE, $3, $4)
$$;

alter function st_approxquantile(text, text, double precision, double precision[], out double precision, out double precision) owner to pmfarr;

