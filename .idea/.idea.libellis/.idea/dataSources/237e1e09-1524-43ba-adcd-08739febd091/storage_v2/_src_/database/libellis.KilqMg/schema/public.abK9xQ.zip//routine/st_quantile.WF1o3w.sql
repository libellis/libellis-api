create function st_quantile(rast raster, nband integer, quantile double precision) returns double precision
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT ( public._ST_quantile($1, $2, TRUE, 1, ARRAY[$3]::double precision[])).value
$$;

comment on function st_quantile(raster, integer, double precision) is 'args: rast, nband, quantile - Compute quantiles for a raster or raster table coverage in the context of the sample or population. Thus, a value could be examined to be at the rasters 25%, 50%, 75% percentile.';

alter function st_quantile(raster, integer, double precision) owner to pmfarr;

