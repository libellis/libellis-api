create function st_makeemptyraster(width integer, height integer, upperleftx double precision, upperlefty double precision, pixelsize double precision) returns raster
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT  public.ST_makeemptyraster($1, $2, $3, $4, $5, -($5), 0, 0, public.ST_SRID('POINT(0 0)'::geometry))
$$;

comment on function st_makeemptyraster(integer, integer, double precision, double precision, double precision) is 'args: width, height, upperleftx, upperlefty, pixelsize - Returns an empty raster (having no bands) of given dimensions (width & height), upperleft X and Y, pixel size and rotation (scalex, scaley, skewx & skewy) and reference system (srid). If a raster is passed in, returns a new raster with the same size, alignment and SRID. If srid is left out, the spatial ref is set to unknown (0).';

alter function st_makeemptyraster(integer, integer, double precision, double precision, double precision) owner to pmfarr;

