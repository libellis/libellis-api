create view users_votes as
SELECT votes.username,
       questions.survey_id,
       choices.question_id,
       votes.choice_id,
       votes.score
FROM ((votes
  JOIN choices ON ((votes.choice_id = choices.id)))
       JOIN questions ON ((questions.id = choices.question_id)));

alter table users_votes
  owner to pmfarr;

